bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example1.fasta -S ./SE/sam/example1.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example2.fasta -S ./SE/sam/example2.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example3.fasta -S ./SE/sam/example3.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example4.fasta -S ./SE/sam/example4.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example5.fasta -S ./SE/sam/example5.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example6.fasta -S ./SE/sam/example6.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example7.fasta -S ./SE/sam/example7.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example8.fasta -S ./SE/sam/example8.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example9.fasta -S ./SE/sam/example9.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example10.fasta -S ./SE/sam/example10.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example11.fasta -S ./SE/sam/example11.sam
bowtie2 -f -p 2  -k 20 --reorder --no-unal --no-hd --no-sq -x Homo_sapiens.GRCh37.71.cdna.all -U ./SE/fasta/example12.fasta -S ./SE/sam/example12.sam

python extract_data.py SE 12