#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE1_1.fastq -2 ./PE/fastq/PE1_2.fastq -S ./PE/sam/example1.sam
#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE2_1.fastq -2 ./PE/fastq/PE2_2.fastq -S ./PE/sam/example2.sam
#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE3_1.fastq -2 ./PE/fastq/PE3_2.fastq -S ./PE/sam/example3.sam
#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE4_1.fastq -2 ./PE/fastq/PE4_2.fastq -S ./PE/sam/example4.sam
#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE5_1.fastq -2 ./PE/fastq/PE5_2.fastq -S ./PE/sam/example5.sam
#bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE6_1.fastq -2 ./PE/fastq/PE6_2.fastq -S ./PE/sam/example6.sam
bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE7_1.fastq -2 ./PE/fastq/PE7_2.fastq -S ./PE/sam/example7.sam
bowtie2 -q -p 4 -k 20 --reorder --no-unal --no-hd --no-sq --no-mixed --no-discordant -x Homo_sapiens.GRCh37.71.cdna.all -1 ./PE/fastq/PE8_1.fastq -2 ./PE/fastq/PE8_2.fastq -S ./PE/sam/example8.sam

#python extract_data.py PE 8