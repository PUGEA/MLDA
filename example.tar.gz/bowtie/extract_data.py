import sys

readTy = sys.argv[1]
num =int(sys.argv[2])
for i in range(1,num+1):
    name1 = './'+readTy+'/sam/example'+str(i)+'.sam'
    name2 = './'+readTy+'/sam/example'+str(i)
    with open(name1,'rb')as fr:
        with open(name2,'w')as fw:
            for line in fr:
                line=line.rstrip();
                line=line.split("\t")
                read=line[0];
                iso=line[2];
                loc=line[3];
                fw.write(str(read)+'\t'+str(iso)+'\t'+str(loc)+'\n')
